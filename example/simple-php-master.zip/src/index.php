<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OpenXpress - Home</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            color: #333;
        }
        header {
            background-color: #4CAF50;
            color: white;
            padding: 10px 0;
            text-align: center;
        }
		nav {
			background-color: #000;
		}
        nav ul {
            list-style-type: none;
            padding: 0;
        }
        nav ul li {
            display: inline;
            margin: 0 10px;
        }
        nav ul li a {
            color: white;
            text-decoration: none;
        }
        main {
            padding: 20px;
            text-align: center;
        }
        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px 0;
            position: fixed;
            width: 100%;
            bottom: 0;
        }
    </style>
</head>
<body>
    <?php
    $title = "Welcome to OpenXpress";
    $aboutUs = "OpenXpress is dedicated to providing the best service possible. We aim to meet and exceed your expectations with our wide range of offerings.";
    $services = "We offer a variety of services to cater to your needs. Whether it's delivery, logistics, or customer support, we have you covered.";
    $contactEmail = "info@openxpress.com";
    ?>

    <header>
        <h1><?php echo $title; ?></h1>
    </header>
    <main>
		<nav>
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="content.php">Content</a></li>
			</ul>
		</nav>
        <section>
            <h2>About Us</h2>
            <p><?php echo $aboutUs; ?></p>
        </section>
        <section>
            <h2>Services</h2>
            <p><?php echo $services; ?></p>
        </section>
        <section>
            <h2>Contact Us</h2>
            <p>Have any questions? Feel free to reach out to us at <a href="mailto:<?php echo $contactEmail; ?>"><?php echo $contactEmail; ?></a>.</p>
        </section>
    </main>
    <footer>
        <p>&copy; 2024 OpenXpress. All rights reserved.</p>
    </footer>
</body>
</html>
