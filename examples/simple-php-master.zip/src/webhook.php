<?php
// Set the log file path
$logFile = '/var/www/html/logs/webhook.log';

// Create logs directory if it doesn't exist
if (!file_exists(dirname($logFile))) {
    mkdir(dirname($logFile), 0777, true);
}

// Get the incoming request data
$requestBody = file_get_contents('php://input');
$requestHeaders = getallheaders();
$requestMethod = $_SERVER['REQUEST_METHOD'];
$requestUri = $_SERVER['REQUEST_URI'];
$timestamp = date('Y-m-d H:i:s');

// Prepare the log entry
$logEntry = [
    'timestamp' => $timestamp,
    'method' => $requestMethod,
    'uri' => $requestUri,
    'headers' => $requestHeaders,
    'body' => json_decode($requestBody, true)
];

// Log the entry to the file
file_put_contents($logFile, json_encode($logEntry, JSON_PRETTY_PRINT) . PHP_EOL, FILE_APPEND);

// Send a response back to the client
header('Content-Type: application/json');
echo json_encode(['status' => 'success', 'message' => 'Webhook received and logged.']);
?>
