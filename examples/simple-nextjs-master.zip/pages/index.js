import Head from 'next/head'
import Header from '../components/Header'
import Footer from '../components/Footer'

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <Head>
        <title>My Next.js Site</title>
        <meta name="description" content="A sample Next.js site with Tailwind CSS" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      
      <Header />

      <main className="flex-grow container mx-auto px-4">
        <h1 className="text-4xl font-bold text-center my-8">Welcome to My Next.js Site!</h1>
        <p className="text-center text-lg">
          This is a sample theme created with Next.js and Tailwind CSS.
        </p>
      </main>

      <Footer />
    </div>
  )
}
