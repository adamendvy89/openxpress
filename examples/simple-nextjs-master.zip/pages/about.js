import Header from '../components/Header'
import Footer from '../components/Footer'

export default function About() {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-grow container mx-auto px-4">
        <h1 className="text-4xl font-bold text-center my-8">About Us</h1>
        <p className="text-center text-lg">
          We are a company dedicated to providing the best services to our customers.
        </p>
      </main>

      <Footer />
    </div>
  )
}
